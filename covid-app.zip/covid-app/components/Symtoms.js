import React from 'react';
import {
  Text,
  View,
  StyleSheet,
  StatusBar,
  Dimensions,
  TouchableOpacity
 
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FlatList} from 'react-native-gesture-handler';
import { createNativeStackNavigator } from '@react-navigation/native-stack';


const screenWidth = Dimensions.get('window').width;
const Stack = createNativeStackNavigator();


const colors = {
  themeColor: '#ffc66a',
  white: '#fff',
  backgroud: '#f4f6fc',
  greyish: 'a5a5a5',
};

const symptom = [
  {
    symptom: 'Cold',
    icon: 'snowflake',
    selected: false,
  },
  {
    symptom: 'Dry Cough',
    icon: 'flash',
    selected: false,
    
  },
  {
    symptom: 'Fever',
    icon: 'thermometer',
    selected: false,
  },
  {
    symptom: 'Breathing Difficulty',
    icon: 'air-filter',
    selected: false,
  },
];

const Symptom = ({ symptom, icon, selected, color, navigation }) => {
  return (
    <View
      style={{
        backgroundColor: selected? color.themeColor :colors.white,
        margin: 4,
        paddingHorizontal: 8,
        paddingVertical: 20,
        borderRadius: 20,
        width: (screenWidth - 64) / 2,
      }}>
      <Text
        style={{
          fontSize: 20,
          fontWeight: '500',
          color: colors.greyish,
          
        }}>
        {symptom}

      </Text>
      <Text 
      style={{
        fontSize:16,
        marginVertical:7,
        color: selected? colors.white: colors.greyish
        }}> Common symptoms of Covid-19 </Text>
        
   <MaterialCommunityIcons 
    name={icon}
    size={45}
    style={{alignSelf:"flex-end",
    color: colors.themeColor}}
   
   />
  
    </View>
 
  );
};

export default function Symptoms(props) {
  return (
    <View
      style={{
        backgroundColor: colors.backgroud,
        paddingHorizontal: 8,
      }}>
      <StatusBar backgroundColor={colors.backgroud} barStyle="dark-content" />
      <View
        style={{
          padding: 16,
          flexDirection: 'row',
          justifyContent: 'space-between',
        }}>
        
        <TouchableOpacity  onPress={() => {
            navigation.navigate('States');
          }}>
        <MaterialCommunityIcons name="magnify" size={30} />
        <Text> Search for States</Text>
        </TouchableOpacity>
      </View>

      <View
        style={{
          padding: 16,
          flexDirection: 'row',
          justifyContent: 'space-between',
        }}>
        <View>
          <Text style={{ fontSize: 16 }}> COVID-19</Text>
          <Text style={{ fontSize: 20 }}> Symptoms</Text>
        </View>
        <MaterialCommunityIcons
          name="thermometer"
          size={45}
          style={{
            color: colors.white,
            backgroundColor: colors.themeColor,
          
          }}
        />
      </View>

      <View
        style={{
          borderTopWidth: 6,
          borderTopColor: colors.themeColor,
          borderRadius: 3,
          marginHorizontal: 16,
          width: 40,
            marginTop:-5
        }}
      />

      <View
        style={{
          paddingHorizontal: 8,
          paddingVertical: 30,
        }}>
        <FlatList
          numColumns={2}
          data={symptom}
          keyExtractor={(item) => item.symptom}
          renderItem={({ item }) => (
            <Symptom
              symptom={item.symptom}
              icon={item.icon}
              selected={item.selected}
            />
          )}
        />
      </View>
    </View>
  );
}


