import React from 'react';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FlatList} from 'react-native-gesture-handler'
import 'react-native-gesture-handler';
import navigation from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StyleSheet, View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import StackNavigator from '@react-navigation/native';
import Symptoms from './components/Symtoms';
import States from './components/States'
import Prevention from './components/Prevention'

const Stack = createNativeStackNavigator();


export default function App() {
  return (
   
   <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Symptoms" component={Symptoms} /> 
        <Stack.Screen name="States" component={States} />
        <Stack.Screen name="Prevention" component={Prevention} />
      </Stack.Navigator>
    </NavigationContainer>
    
  );
}

